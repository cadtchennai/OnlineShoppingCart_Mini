package com.techm.auth.jwt;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureException;

import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.hazelcast.client.HazelcastClient;
import com.hazelcast.client.config.ClientConfig;
import com.hazelcast.core.HazelcastInstance;
import com.hazelcast.core.IMap;
import com.netflix.config.ConfigurationManager;
import com.netflix.config.DynamicPropertyFactory;
import com.netflix.config.DynamicStringProperty;
import com.techm.auth.hystrix.GenerateToken;
import com.techm.auth.hystrix.TokenIsValid;




@RestController
@RequestMapping(value="/loginService")
@Component

public class GenerateJwtToken {		
	public String getDynamicIp() throws Exception {
		 ConfigurationManager.loadCascadedPropertiesFromResources("application");
			DynamicStringProperty host = DynamicPropertyFactory.getInstance()
					.getStringProperty("server.host", "");
			DynamicStringProperty port = DynamicPropertyFactory.getInstance()
					.getStringProperty("zuulPort", "");
			
			DynamicStringProperty protocol = DynamicPropertyFactory.getInstance()
					.getStringProperty("protocol", "");	
			
			String completepath = protocol.get()+"://"+host.get()+":"+port.get();	
			//System.out.println("value of completepath= "+completepath);
			return completepath;
	}
	
	//private static final String signingKey = "my-jwt-secret-token";
	 
	/*   //  String token = null ;
	    private static final Logger LOGGER = LoggerFactory.getLogger(GenerateJwtToken.class);
	    String customlogger ="ADMS Loger::::";
	
	

@RequestMapping(value= "/isValid",method = RequestMethod.POST, produces = "application/json")	


public static boolean validateJWT( @RequestBody String compactJws,HttpServletResponse httpServletResponse ) {
	 //System.out.println("validateJWT Started:::::");
	 //String compactJws = compactJws1.toString();
	// System.out.println("value of compactJws= "+compactJws);
	 boolean isValid = false;
	 String secretkey = "my-jwt-secret-token";
    try {
        Jwts.parser().setSigningKey(secretkey).parseClaimsJws(compactJws);
        isValid = true;
        Claims claims = Jwts.parser().setSigningKey(secretkey).parseClaimsJws(compactJws).getBody();
        System.out.println("claims.getSubject():::"+claims.getSubject());
        System.out.println("value of isValid= "+isValid);
    } catch (SignatureException e) {
           System.out.println("Exception :::"+e);
    }
    return isValid;
}
    
    @RequestMapping(value="/test")
    public String test(){
    	return "success";
    }

    
    
   

    
    
	@RequestMapping(value="/generateToken",method = RequestMethod.POST, produces = "application/json")	

	public String generateToken(HttpServletResponse httpServletResponse,@RequestBody String userCredentials,HttpServletRequest httpServletRequest) {
		String token =null;
       
		LOGGER.info(customlogger+"GenerateJwtToken Started");
		LOGGER.info(customlogger+"Loggedin User Credentials ::" + userCredentials);
		JSONObject userCredjson = null;
		String username = null;
		String password = null;
		try {
			if (userCredentials != null)
				userCredjson = new JSONObject(userCredentials.toString());
			if (userCredjson != null) {
				username = userCredjson.optString("userName");
				//System.out.println("username------"+username);
				//System.out.println("username--aaa----"+userCredjson);
				password = userCredjson.optString("password");
				LOGGER.info(customlogger+"Entered username ::"+username+"\t Entered password ::"+password);
				
				
				
				
				RestTemplate restTemplate = new RestTemplate();	
				//System.out.println("CopyFileOperation()= "+getDynamicIp());
				String res = restTemplate.postForObject(getDynamicIp()+"/customer-service/customer/getCustomer", userCredentials, String.class);
				
				
				//System.out.println("value of res= "+res);
			        
				//String res="success";
				if(res.equals("success")){
				
				 token = JwtUtil.generateToken(signingKey, username,password);
				LOGGER.info(customlogger+"Generated JwtToken:::" +token);
				System.out.println("success");
				String value = new StringBuilder(ipAddress).append("-").append(username).toString();
				System.out.println(value);
				jwttoken.put(value,token);
				
			
		}
				else{
					token = null;	
				}
				}
		} catch (Exception e) {
			LOGGER.error(customlogger+"Exception Occured in generateToken() method");
			e.printStackTrace();
		}
		
		//System.out.println("Yet to return token= "+token);
		
		return token;
	}
	


*/
	

	@RequestMapping(value= "/isValid",method = RequestMethod.POST, produces = "application/json")	


	public String isValid(/*@RequestBody Map<String, String> jwt*/@RequestBody List<String> listToken ,HttpServletResponse httpServletResponse,HttpServletRequest httpServletRequest){
		/* Map<String, String> jwt = new HashMap<String, String>();
				jwt.put("token", jwtToken);*/
		System.out.println( "isValid() starts" );
		String result="";
		String tokenResult="";
		//String value =jwt.get("token");
		//List<String> listToken=(List<String>) jwt.get("token");
		//List<String> listIp=(List<String>) jwt.get("ipAddressOrder");
		TokenIsValid tokenIsValid=new TokenIsValid();
		tokenIsValid.execute();
		/*List<String> listToken= new ArrayList<String>();
		listToken.add( 0,jwt.get("token"));
		listToken.add( 1,jwt.get("ipAddressOrder"));*/
		//listToken1.addAll( 0,jwt.get("token"));
		String token = listToken.get(0) ;
		String ipAddressOrder = listToken.get(1);
		//String token =jwt.get("token");
		System.out.println("check token from header: "+token+"   "+"ip= "+ipAddressOrder);
		
		//String ipAddressOrder= jwt.get("ipAddressOrder");
		//String ipAddressOrder=(String) listToken.get(1);
		System.out.println("ipAddressOrder: "+ipAddressOrder);

		String ipAddressOrder1 =  httpServletRequest.getRemoteAddr();
		System.out.println("IP Address: "+ipAddressOrder);
		
		ClientConfig clientConfig = new ClientConfig();
		
			clientConfig.getGroupConfig().setName("dev").setPassword("dev-pass");
			clientConfig.getNetworkConfig().addAddress("172.18.32.167:5701", "172.18.32.167:5702");
			
			HazelcastInstance client = HazelcastClient.newHazelcastClient(clientConfig);
			IMap<String, String> map = client.getMap( "jwttoken" );	

			
			 /*System.out.println( "map Values: " + map );
	    	 System.out.println( "Token from hazel cast :" + map.values().toString() );
	    	 System.out.println("key is of ip address from hazel cast= "+map.keySet().toString());*/
			
	    	String authvalue= map.keySet().toString();
	    	  result= authvalue.replaceAll("[\\[\\]]","");
	    	
	    	  String replace = map.values().toString();
	    	  tokenResult = replace.replaceAll("[\\[\\]]","");
	    	//result=authvalue;
	    	
	    	System.out.println("authvalue--"+result);
	    
			
			//String listObj = token.get(0);
			
			String jwtUsername = JwtUtil.getSubject(httpServletResponse,token, signingKey);
			String jwtPassword = JwtUtil.getPassword(httpServletResponse,token, signingKey);
			LOGGER.info("::::::Jwt User credentials after Parsing:::::");
			LOGGER.info("username::" + jwtUsername);
			LOGGER.info("password::" + jwtPassword);

		
			LOGGER.info("Customer Object from Customer Service ::::");
			 String valueOrder = new StringBuilder(ipAddressOrder).append("-").append(jwtUsername).toString();
			 /*System.out.println("value after  eliminated [ ]");
			 System.out.println("result eliminated [ ]"+result);
			    System.out.println("valueOrder from hazel cast that is IP after eliminating ip and appending []----"+valueOrder);
			    System.out.println("tokenResult eliminated [ ]"+tokenResult);*/
			/*try {
				
				//user defined true result 
				if (jwtUsername != null) {
					result="validToken";
					LOGGER.info("JWT Token Validataion Sucessful in Order Service.");
					return result;
				}
				else{
					result="notValid";
					return result;
				}*/
				//ends
				boolean validation=false;
				if (jwtUsername != null) {
					if ((token.equals(tokenResult)) && (result.equals(valueOrder)) ) {
						validation = true;
						result="validToken";
						LOGGER.info("JWT Token Validataion Sucessful in Service.");
						return result;
					} 
					else if(result.equals(null)||result.equals("")){
						result="notValid";
						System.out.println("inside result null");
						return result;
					}
					else
					{
						
						result="notValid";
						LOGGER.info("JWT Token Validataion failed in Service.");
						validation = false;
						return result;
					}
				} 
				else {
					result="username is not valid";
					validation = false;
					return result;
				}

				
				
			/*} catch (Exception e) {
				
			}
			*/
		//return result;	
				
		
		
	}
	    private static final String signingKey = "signingKey";
	    String token = null ;
	    private static final Logger LOGGER = LoggerFactory.getLogger(GenerateJwtToken.class);
	    String customlogger ="ADMS Loger::::";
	   
		@RequestMapping(value="/generateToken",method = RequestMethod.POST, produces = "application/json")	

		public String generateToken(HttpServletResponse httpServletResponse,@RequestBody String userCredentials,HttpServletRequest httpServletRequest) {
			GenerateToken generateToken=new GenerateToken();
			generateToken.execute();
			String result=null;
	    	String ipAddress =  httpServletRequest.getRemoteAddr();
	    	System.out.println("IP Address: "+ipAddress);
	    	RestTemplate restTemplate = new RestTemplate();	
			System.out.println("userCredentials: "+userCredentials);
			
			
			String res=restTemplate.postForObject("http://localhost:9090/customer-service/customer/getCustomer", userCredentials, String.class);
			System.out.println("value of res= "+res);
			
			//hazelcast
	    	  ClientConfig clientConfig = new ClientConfig();
	    	  System.out.println("clientConfig----"+clientConfig);
	       
			clientConfig.getGroupConfig().setName("dev").setPassword("dev-pass");
			
			clientConfig.getNetworkConfig().addAddress("172.18.32.167:5701", "172.18.32.167:5702");
			
			
			
			
		    HazelcastInstance client = HazelcastClient.newHazelcastClient(clientConfig);
		    
		   
	        IMap<String, String> jwttoken = client.getMap("jwttoken");
	       
	    	
	        jwttoken.evictAll();
	       
	       
	       
			LOGGER.info(customlogger+"GenerateJwtToken Started");
			LOGGER.info(customlogger+"Loggedin User Credentials ::" + userCredentials);
			JSONObject userCredjson = null;
			String username = null;
			String password = null;
			try {
				if (userCredentials != null)
					userCredjson = new JSONObject(userCredentials.toString());
				if (userCredjson != null) {
					username = userCredjson.optString("userName");
					System.out.println("username------"+username);
					System.out.println("username--aaa----"+userCredjson);
					password = userCredjson.optString("password");
					LOGGER.info(customlogger+"Entered username ::"+username+"\t Entered password ::"+password);
					
					
					
					
					
					//String res="success";
					if(res.equals("success")){
					
					token = JwtUtil.generateToken(signingKey, username,password);
					LOGGER.info(customlogger+"Generated JwtToken:::" +token);
					System.out.println("success");
					String value = new StringBuilder(ipAddress).append("-").append(username).toString();
					System.out.println(value);
					jwttoken.put(value,token);
					
				
				}
					}
			} catch (Exception e) {
				LOGGER.error(customlogger+"Exception Occured in generateToken() method");
				e.printStackTrace();
			}
			
			
			return token;
		}
		


}
